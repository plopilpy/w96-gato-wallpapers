A Windows 96 wallpaper pack full of gatos.

Copyright (C) Plopilpy, 2021.